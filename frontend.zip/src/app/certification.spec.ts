import { Certification } from './certification';

describe('Certification', () => {
  it('should create an instance', () => {
    expect(new Certification()).toBeTruthy();
  });
});
