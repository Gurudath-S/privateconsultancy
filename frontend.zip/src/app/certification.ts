export class Certification {
    id: number;
    name: string;
}
